# Upwork: публічна вибірка бюджетів

Перевірено 2026-10-12. Відкриті сторінки категорій, без входу в акаунт.
Це найменші видимі fixed-price бюджети у переглянутій вибірці, не мінімум всієї
платформи, не виконані угоди, не ставки виконавців. Активність конкретної вакансії
та повний обсяг роботи потребують перевірки. Позначки «Posted» наведені самим сайтом.

| Категорія | Найменший видимий бюджет | Приклад | Інші видимі бюджети |
|---|---:|---|---|
| Python | $100 | eCommerce Automation Developer Needed Phython or anything else | $150, $500, $550, $10,000 |
| Excel | $10 | Data Entry and Web Research Specialist | $15, $100, $250 |
| Word | $5 | Transcribe Documents into Editable Microsoft Word Format | $10 |
| PowerPoint | $30 | PowerPoint presentation Designer | $50 за приклад deck на 10 слайдів, $120 |
| Translation | $15 | English to Azerbaijani or Kyrgyz Translators Needed | $25, $100, $225, $240, $3,000 |
| Content writing | $10 | Scriptwriter Needed for a Short Film, 5 сторінок | $70 за покращення YouTube-сценарію |

Переклади в цій вибірці не EN↔UK, тому $15 — тільки загальний орієнтир малих
контрактів, не вимір ціни українського перекладу. Word включає конвертацію,
Excel — data entry; це не порівнянні за складністю послуги.
Категорія writing має нерелевантні оголошення; вони не використані як ціна статті.

Загальні ціни фірми — редакційне рішення на основі низьких видимих бюджетів і
витрат, а не статистична оцінка. $50 для коду нижче мінімуму переглянутої Python
вибірки, бо наш стартовий пакет має значно вужчий обсяг. Число вакансій не вимірювали
репрезентативно, середні й конверсії не розраховували. Повторити аналіз після
10 виконаних робіт і накопичення фактичних витрат на заявки.

Джерела:
- https://www.upwork.com/freelance-jobs/python/
- https://www.upwork.com/freelance-jobs/microsoft-excel/
- https://www.upwork.com/freelance-jobs/microsoft-word/
- https://www.upwork.com/freelance-jobs/microsoft-powerpoint/
- https://www.upwork.com/freelance-jobs/translation/
- https://www.upwork.com/freelance-jobs/content-writing/
