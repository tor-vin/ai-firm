import unittest,json
from io import BytesIO
from unittest.mock import patch
import firm
class Tests(unittest.TestCase):
    def test_economics(self):
        j=firm.validate(json.loads((firm.ROOT/'example-job.json').read_text()))
        self.assertEqual(firm.economy(j,10)['after_owner_time_usd'],40)
    def test_invalid(self):
        for n in [-1,float('nan'),float('inf')]:
            with self.assertRaises(ValueError): firm.amount(n)
    def test_budget(self):
        d=firm.connect(':memory:'); firm.reserve(d,90,150,'test')
        with self.assertRaises(ValueError): firm.reserve(d,61,150,'test')
        self.assertEqual(firm.used(d),90)
    def setup_ai(self):
        d=firm.connect(':memory:'); d.execute('INSERT INTO jobs(id,payload) VALUES(1,?)',(json.dumps({'title':'test'}),)); d.commit(); return d
    def test_timeout(self):
        d=self.setup_ai()
        with patch.dict('os.environ',{'OPENAI_API_KEY':'test','OPENAI_MODEL':'test','OPENAI_INPUT_USD_PER_MILLION':'1','OPENAI_OUTPUT_USD_PER_MILLION':'1'}),patch('urllib.request.urlopen',side_effect=TimeoutError()):
            with self.assertRaises(TimeoutError): firm.analyze(d,1,{'verified_skills':['test'],'monthly_expense_cap_usd':150})
        self.assertEqual(d.execute('SELECT state FROM costs').fetchone()[0],'uncertain')
        self.assertGreater(firm.used(d),0)
    def test_success(self):
        d=self.setup_ai(); response={'status':'completed','usage':{'input_tokens':100,'output_tokens':50},'output':[{'content':[{'type':'output_text','text':json.dumps({'analysis':'Check scope','proposal':'Draft'})}]}]}
        with patch.dict('os.environ',{'OPENAI_API_KEY':'test','OPENAI_MODEL':'test','OPENAI_INPUT_USD_PER_MILLION':'1','OPENAI_OUTPUT_USD_PER_MILLION':'2'}),patch('urllib.request.urlopen',return_value=BytesIO(json.dumps(response).encode())):
            firm.analyze(d,1,{'verified_skills':['test'],'monthly_expense_cap_usd':150})
        self.assertEqual(d.execute('SELECT state FROM jobs').fetchone()[0],'review')
        self.assertAlmostEqual(firm.used(d),0.0002)

class PricingTests(unittest.TestCase):
    def test_acquisition_adjusts_floor(self):
        profile=json.loads((firm.ROOT/'profile.json').read_text())
        job=firm.validate(json.loads((firm.ROOT/'example-job.json').read_text()))
        gate=firm.pricing_gate(job,profile)
        self.assertEqual(gate['expected_acquisition_usd'],15)
        self.assertEqual(gate['required_quote_usd'],60)
        self.assertTrue(gate['eligible'])
        job['budget']=20
        self.assertFalse(firm.pricing_gate(job,profile)['eligible'])
    def test_unknown_category_requires_review(self):
        profile=json.loads((firm.ROOT/'profile.json').read_text())
        job=json.loads((firm.ROOT/'example-job.json').read_text()); job['category']='unknown'
        self.assertFalse(firm.pricing_gate(job,profile)['eligible'])
